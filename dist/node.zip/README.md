# VisualBox Integration in Node.js
This is a short and simple integration showing how a Node.js integration can be written.
